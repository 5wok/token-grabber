# discord-grabber-poc
> discord token and userinfo grabber

Proof of concept of grabbing discord user information and session tokens by abusing the overlay IPC socket.

## How to use

```sh
npm install
node index.js
```

## Showcase
![demo](https://i.imgur.com/a9wJ00w.png)